﻿namespace Dice.Client.Web
{
    public enum Currencies
    {
        None = 0, BTC, Doge, LTC
    }
}
